-- ============================================================
-- FundScope Database Schema — IA Unit Trusts & OEICs
-- ============================================================

CREATE TABLE IF NOT EXISTS sectors (
    sector_code         TEXT PRIMARY KEY,   -- e.g. "IA UK All Companies"
    sector_name         TEXT NOT NULL,       -- short display name
    monitored           INTEGER DEFAULT 0,  -- 1 = user has enabled this sector
    min_funds_decile    INTEGER DEFAULT 20,
    created_at          TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS funds (
    fund_id         TEXT PRIMARY KEY,        -- slugified name or ISIN
    fund_name       TEXT NOT NULL,
    isin            TEXT,
    sedol           TEXT,
    sector_code     TEXT REFERENCES sectors(sector_code),
    fund_group      TEXT,                    -- management company
    active          INTEGER DEFAULT 1,
    first_seen      TEXT,
    last_seen       TEXT,
    created_at      TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS fund_performance (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    fund_id         TEXT NOT NULL REFERENCES funds(fund_id),
    week_date       TEXT NOT NULL,
    return_1m       REAL,
    return_3m       REAL,
    return_6m       REAL,
    return_1y       REAL,
    return_3y       REAL,
    created_at      TEXT DEFAULT (datetime('now')),
    UNIQUE(fund_id, week_date)
);

CREATE TABLE IF NOT EXISTS fund_rankings (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    fund_id         TEXT NOT NULL REFERENCES funds(fund_id),
    sector_code     TEXT NOT NULL REFERENCES sectors(sector_code),
    week_date       TEXT NOT NULL,
    decile_1m       INTEGER,
    decile_3m       INTEGER,
    decile_6m       INTEGER,
    quartile_1m     INTEGER,
    quartile_3m     INTEGER,
    quartile_6m     INTEGER,
    rank_1m         INTEGER,
    rank_3m         INTEGER,
    rank_6m         INTEGER,
    total_in_sector INTEGER,
    streak_1m       INTEGER DEFAULT 0,
    streak_3m       INTEGER DEFAULT 0,
    streak_6m       INTEGER DEFAULT 0,
    created_at      TEXT DEFAULT (datetime('now')),
    UNIQUE(fund_id, sector_code, week_date)
);

CREATE TABLE IF NOT EXISTS alert_history (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    fund_id         TEXT NOT NULL REFERENCES funds(fund_id),
    sector_code     TEXT NOT NULL,
    week_date       TEXT NOT NULL,
    alert_type      TEXT NOT NULL,
    period          TEXT NOT NULL,
    prev_decile     INTEGER,
    curr_decile     INTEGER,
    streak_broken   INTEGER,
    return_value    REAL,
    created_at      TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS digest_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    week_date       TEXT NOT NULL,
    sent_at         TEXT,
    alert_count     INTEGER DEFAULT 0,
    status          TEXT DEFAULT 'pending',
    error_message   TEXT
);

CREATE TABLE IF NOT EXISTS pipeline_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    run_date        TEXT NOT NULL,
    sector_code     TEXT,
    status          TEXT,
    funds_scraped   INTEGER DEFAULT 0,
    error_message   TEXT,
    duration_secs   REAL,
    created_at      TEXT DEFAULT (datetime('now'))
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_perf_fund_date  ON fund_performance(fund_id, week_date);
CREATE INDEX IF NOT EXISTS idx_perf_week       ON fund_performance(week_date);
CREATE INDEX IF NOT EXISTS idx_rank_sector_date ON fund_rankings(sector_code, week_date);
CREATE INDEX IF NOT EXISTS idx_rank_fund_date  ON fund_rankings(fund_id, week_date);
CREATE INDEX IF NOT EXISTS idx_alert_date      ON alert_history(week_date);
